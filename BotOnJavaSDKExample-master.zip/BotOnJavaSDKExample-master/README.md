# BotOnJavaSDKExample

## Быстрый запуск
1. Создайте файл **vkconfig.properties** в директории BotOnJavaSDKExample/src/main/resources/
2. Сохраните там access token и group Id
3. Запустите BotOnJavaSDKExample/src/main/java/vk/VKServer

Подробнее смотрите в статье: [на datastock](https://datastock.biz/threads/sozdanie-bota-na-java-dlja-servisa-vkontakte-chast-1.383/#post-2108)<br>
Также: https://vk.com/@apploidxxx-sozdanie-prostoi-arhitektury-bota-dlya-vnedreniya-v-sistemu
