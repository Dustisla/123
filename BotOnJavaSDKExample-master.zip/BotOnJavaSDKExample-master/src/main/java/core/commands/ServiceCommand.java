package core.commands;

/**
 * @author Arthur Kupriyanov
 */
public interface ServiceCommand {
    void service();
}
